%%
pyr = gaussian_pyramid(zeros(hei,wid));
nlev = length(pyr);

pyrW=gaussian_pyramid(weightMap,nlev);
pyrI1=laplacian_pyramid(img1_gray,nlev);
pyrI2=laplacian_pyramid(img2_gray,nlev);

for l = 1:nlev
   pyr{l}=band_fuse(pyrI1{l},pyrI2{l},pyrW{l},0.6);
end

%% Reconstruct
imgf = reconstruct_laplacian_pyramid(pyr);
imgf_YUV = zeros(hei,wid,3);
imgf_YUV(:,:,1) = imgf;
imgf_YUV(:,:,2)=img2_YUV(:,:,2);
imgf_YUV(:,:,3)=img2_YUV(:,:,3);
imgf_RGB=ConvertYUVtoRGB(imgf_YUV);
imrec=uint8(imgf_RGB*255);

toc;
subplot(131),imshow(img1);title('MR-Gad')
subplot(132),imshow(img2);title('SPECT-Tc')
subplot(133),imshow(imrec);title('Fused Output')
imwrite(imrec,'results/fused.tif');
%%
quality_analysis
%%