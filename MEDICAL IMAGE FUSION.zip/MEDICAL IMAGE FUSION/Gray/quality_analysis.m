clc
%%
[M,N]=size(imrec);
if size(imrec,3)>1
    imrec = rgb2gray(imrec);
end
[ pt rf1]=uigetfile('.tif','select the reference image');
rf=imread([rf1 pt]);
rf=im2double(rf);
if size(rf,3)>1
    rf=rgb2gray(rf);
end
rf=imresize(rf,size(imrec));
imrec=im2double(imrec);
mse=(sum(sum((rf-imrec).*(rf-imrec)))/(M*N));
rm=sqrt(mse);
disp(['The RMS Error for Proposed is ',num2str(rm)])
E=entropy(imrec);
disp(['The Entropy for Proposed is ',num2str(E)])
CC=corr2(rf,imrec);
disp(['The correlation coefficient for Proposed is ',num2str(CC)])
[mssim,ssim_map] = ssim_index(rf, imrec);
disp(['The SSIM for Proposed is ',num2str(mssim)])
PSNR=20*log10(255/sqrt(mse))
%%
