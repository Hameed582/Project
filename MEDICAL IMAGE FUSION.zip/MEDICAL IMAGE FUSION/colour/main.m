%%
clear
close all
clc
  
%% Parameters           
r=25; 
eps=2.1;
cov_wsize=5;

%% source image 1
I1=uigetfile('*.*', 'Select CT');
I1=double(imread(I1));
 if size(I1,3)==3
 I1=rgb2gray(I1);
 end

%% source image 2
I2=uigetfile('*.*', 'Select MR');
I2=double(imread(I2));

if size(I2,3)==3
 I2=rgb2gray(I2);
end
 
I(:,:,1)=I1;
I(:,:,2)=I2;
 
tic
%% Base and detail layers seperation
A1= guidedfilter(double(I1), double(I2), r, eps);
B1=uint8(A1);
D1=double(I1)-A1;
C1=uint8(D1);


A2=guidedfilter(double(I2), double(I1), r, eps);
B2=uint8(A2);
D2=double(I2)-A2;
C2=uint8(D2);

D(:,:,1)=D1;
D(:,:,2)=D2;
%% Fusion rule
 xfused=GFS_fusion_rule(I,D,cov_wsize);
  toc
 fuseimage=uint8(xfused);
%% Display of images
subplot(131),imshow(I1,[]);title('CT image')
subplot(132),imshow(I2,[]);title('MRI image')
subplot(133), imshow(fuseimage,[]); title('Fused image')
%%
%% Qualitative Evaluation
[M,N]=size(fuseimage);



rf=uigetfile('.jpg','select the reference image');
rf=imread(rf);
rf=im2double(rf);
if size(rf,3)>1
    rf=rgb2gray(rf);
end
rf=imresize(rf,size(fuseimage));
fuseimage=im2double(fuseimage);
mse=(sum(sum((rf-fuseimage).*(rf-fuseimage)))/(M*N));
rm=sqrt(mse);
disp(['The RMS Error for Proposed is ',num2str(rm)])
E=entropy(fuseimage);
disp(['The Entropy for Proposed is ',num2str(E)])
CC=corr2(rf,fuseimage);
disp(['The correlation coefficient for Proposed is ',num2str(CC)])
[mssim,ssim_map] = ssim_index(rf, fuseimage);
disp(['The SSIM for Proposed is ',num2str(mssim)])
PSNR=20*log10(255/sqrt(mse))
%%