%%
clear
close all
clc
  
%% Parameters           
r=25; 
eps=2.1;
cov_wsize=5;

cd colorimages
%% source image 1
I1=uigetfile('*.*', 'Select MR');
I1=imread(I1);
 if size(I1,3)==3
 I1=rgb2gray(I1);
 end
 I1=imresize(I1,[256 256]);

J=uigetfile('*.*', 'Select SPECT');
J=imread(J); 
cd ..
 J=imresize(J,[256 256]);

img2_YUV=ConvertRGBtoYUV(J);
I2=img2_YUV(:,:,1);
[hei, wid] = size(I1);
 
I(:,:,1)=I1;
I(:,:,2)=I2;
 
tic
%% Base and detail layers seperation
A1= guidedfilter(double(I1), double(I2), r, eps);
B1=uint8(A1);
D1=double(I1)-A1;
C1=uint8(D1);

A2=guidedfilter(double(I2), double(I1), r, eps);
B2=uint8(A2);
D2=double(I2)-A2;
C2=uint8(D2);

D(:,:,1)=D1;
D(:,:,2)=D2;
%% Fusion rule
 imgf=GFS_fusion_rule(I,D,cov_wsize);
  toc
 imgf_YUV=zeros(hei,wid,3);
  imgf_YUV(:,:,1)=imgf;
  imgf_YUV(:,:,2)=img2_YUV(:,:,2);
  imgf_YUV(:,:,3)=img2_YUV(:,:,3);
  fuseimage_RGB=ConvertYUVtoRGB(imgf_YUV);
  fuseimage_RGB = uint8(fuseimage_RGB);
%% Display of images
subplot(131),imshow(I1,[]);title('MR image')
subplot(132),imshow(J,[]);title('SPECT image')
subplot(133), imshow(fuseimage_RGB,[]); title('Fused image')
%%
%% Qualitative Evaluation
% E=entropy(fuseimage_RGB);
% disp(['The Entropy for Proposed is ',num2str(E)])
% M = mean2(fuseimage_RGB);
% disp(['The Mean for Proposed is ',num2str(M)])
% S = std2(fuseimage_RGB);
% disp(['The STD for Proposed is ',num2str(S)])
%%

[M,N]=size(fuseimage_RGB);
rf=uigetfile('*.*','select the reference image');
rf=imread(rf);
rf=im2double(rf);

% rf=imresize(rf,size(fuseimage_RGB));
fuseimage_RGB=im2double(fuseimage_RGB);
mse=(sum(sum((rf-fuseimage_RGB).*(rf-fuseimage_RGB)))/(M*N));
rm=sqrt(mse);
disp(['The RMS Error for Proposed is ',num2str(rm)])
E=entropy(fuseimage_RGB);
disp(['The Entropy for Proposed is ',num2str(E)])
CC1=corr2(rf(:,:,1),fuseimage_RGB(:,:,1));
CC2=corr2(rf(:,:,2),fuseimage_RGB(:,:,2));
CC3=corr2(rf(:,:,3),fuseimage_RGB(:,:,3));
CC=(CC1+CC2+CC3)/3;
disp(['The correlation coefficient for Proposed is ',num2str(CC)])
[mssim1,ssim_map1] = ssim_index(rf(:,:,1), fuseimage_RGB(:,:,1));
[mssim2,ssim_map2] = ssim_index(rf(:,:,2), fuseimage_RGB(:,:,2));
[mssim3,ssim_map3] = ssim_index(rf(:,:,3), fuseimage_RGB(:,:,3));
mssim=(mssim1+mssim2+mssim3)/3;
disp(['The SSIM for Proposed is ',num2str(mssim)])

PSNR=20*log10(255/sqrt(mse));
pp1=(PSNR(:,:,1)+PSNR(:,:,2)+PSNR(:,:,3))/3;

disp(['The PSNR for Proposed is ',num2str(pp1)])
